=========
UTILITIES
=========

These are a set of utilities that can be used with different mapping programs

Tectonicus
__________

`Download and Discussion <http://www.minecraftforum.net/viewtopic.php?f=1022&t=95739>`_.

Files::
	
		tectonicus1.18.patch - simple patch to add sundial to a Tectonicus page

Usage::

		cd /minecraft/map/
		patch < /minecraft/sundial/util/tectonicus1.18.patch





